package com.aniket.portal.pojos;

public class CustomerBookingReqPojo {
	String startloc;
	String endloc;
	String depdate;
	public String getStartloc() {
		return startloc;
	}
	public void setStartloc(String startloc) {
		this.startloc = startloc;
	}
	public String getEndloc() {
		return endloc;
	}
	public void setEndloc(String endloc) {
		this.endloc = endloc;
	}
	public String getDeptime() {
		return depdate;
	}
	public void setDeptime(String deptime) {
		this.depdate = deptime;
	}
}